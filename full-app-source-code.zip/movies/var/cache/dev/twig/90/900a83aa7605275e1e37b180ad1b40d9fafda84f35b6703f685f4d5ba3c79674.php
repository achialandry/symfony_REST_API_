<?php

/* @Framework/Form/email_widget.html.php */
class __TwigTemplate_92ac0cf6dfb2153287cf4d2a498662ba4a77cabcf08c5f590c3d6576925dc0b1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_84af3097095e29a72c877cc6a8e53f1639012c27a9a62ce902b9bf94ac60c817 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_84af3097095e29a72c877cc6a8e53f1639012c27a9a62ce902b9bf94ac60c817->enter($__internal_84af3097095e29a72c877cc6a8e53f1639012c27a9a62ce902b9bf94ac60c817_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/email_widget.html.php"));

        $__internal_1f6a1f64bcc2c2a37bec8e2f5e22d0ab68a84b362d83efb4339dbe7dbc60137e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1f6a1f64bcc2c2a37bec8e2f5e22d0ab68a84b362d83efb4339dbe7dbc60137e->enter($__internal_1f6a1f64bcc2c2a37bec8e2f5e22d0ab68a84b362d83efb4339dbe7dbc60137e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/email_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
";
        
        $__internal_84af3097095e29a72c877cc6a8e53f1639012c27a9a62ce902b9bf94ac60c817->leave($__internal_84af3097095e29a72c877cc6a8e53f1639012c27a9a62ce902b9bf94ac60c817_prof);

        
        $__internal_1f6a1f64bcc2c2a37bec8e2f5e22d0ab68a84b362d83efb4339dbe7dbc60137e->leave($__internal_1f6a1f64bcc2c2a37bec8e2f5e22d0ab68a84b362d83efb4339dbe7dbc60137e_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/email_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
", "@Framework/Form/email_widget.html.php", "/var/www/movies/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/email_widget.html.php");
    }
}
