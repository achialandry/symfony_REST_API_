<?php

/* @Framework/Form/widget_container_attributes.html.php */
class __TwigTemplate_b3f91cefe7852822037947ff3bc635dcc1e36a5dce91ce20692cef693b3f6dbe extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_16da61e4a16030aec3e3b6eaa3d91215cccd90389637191415d3bacf84ae549d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_16da61e4a16030aec3e3b6eaa3d91215cccd90389637191415d3bacf84ae549d->enter($__internal_16da61e4a16030aec3e3b6eaa3d91215cccd90389637191415d3bacf84ae549d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/widget_container_attributes.html.php"));

        $__internal_0432aa179d704777d0c44da8364e40cd82aea3e0c6cff211f16318ad7c1d8b74 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0432aa179d704777d0c44da8364e40cd82aea3e0c6cff211f16318ad7c1d8b74->enter($__internal_0432aa179d704777d0c44da8364e40cd82aea3e0c6cff211f16318ad7c1d8b74_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/widget_container_attributes.html.php"));

        // line 1
        echo "<?php if (!empty(\$id)): ?>id=\"<?php echo \$view->escape(\$id) ?>\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
";
        
        $__internal_16da61e4a16030aec3e3b6eaa3d91215cccd90389637191415d3bacf84ae549d->leave($__internal_16da61e4a16030aec3e3b6eaa3d91215cccd90389637191415d3bacf84ae549d_prof);

        
        $__internal_0432aa179d704777d0c44da8364e40cd82aea3e0c6cff211f16318ad7c1d8b74->leave($__internal_0432aa179d704777d0c44da8364e40cd82aea3e0c6cff211f16318ad7c1d8b74_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/widget_container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (!empty(\$id)): ?>id=\"<?php echo \$view->escape(\$id) ?>\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
", "@Framework/Form/widget_container_attributes.html.php", "/var/www/movies/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/widget_container_attributes.html.php");
    }
}
