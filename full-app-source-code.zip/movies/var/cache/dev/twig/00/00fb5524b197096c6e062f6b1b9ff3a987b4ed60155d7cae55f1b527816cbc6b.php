<?php

/* TwigBundle:Exception:error.atom.twig */
class __TwigTemplate_7b3a922812d0c6e0c109fbc0ab5a0fc4625a9a24ebe645a53b76ba214d119507 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_677d8f060d2e95ce8e695811c09c233042a7c88156f3f54fc5c3423be33271c5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_677d8f060d2e95ce8e695811c09c233042a7c88156f3f54fc5c3423be33271c5->enter($__internal_677d8f060d2e95ce8e695811c09c233042a7c88156f3f54fc5c3423be33271c5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        $__internal_95d28b5af4c63962580c9e58130ac8b5807356d2cd2e1cb933d9c6a8a7ef143e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_95d28b5af4c63962580c9e58130ac8b5807356d2cd2e1cb933d9c6a8a7ef143e->enter($__internal_95d28b5af4c63962580c9e58130ac8b5807356d2cd2e1cb933d9c6a8a7ef143e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/error.xml.twig");
        echo "
";
        
        $__internal_677d8f060d2e95ce8e695811c09c233042a7c88156f3f54fc5c3423be33271c5->leave($__internal_677d8f060d2e95ce8e695811c09c233042a7c88156f3f54fc5c3423be33271c5_prof);

        
        $__internal_95d28b5af4c63962580c9e58130ac8b5807356d2cd2e1cb933d9c6a8a7ef143e->leave($__internal_95d28b5af4c63962580c9e58130ac8b5807356d2cd2e1cb933d9c6a8a7ef143e_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/error.xml.twig') }}
", "TwigBundle:Exception:error.atom.twig", "/var/www/movies/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.atom.twig");
    }
}
