<?php

/* TwigBundle:Exception:exception.css.twig */
class __TwigTemplate_f8739e6a37e7a2c51a559f01a2ef43f481dd13581aa531ed724dd69cfe821e31 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6997fbbeb2b0e5505c0a59f6177e2dcadaebdaf402db27bee25489118406acd9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6997fbbeb2b0e5505c0a59f6177e2dcadaebdaf402db27bee25489118406acd9->enter($__internal_6997fbbeb2b0e5505c0a59f6177e2dcadaebdaf402db27bee25489118406acd9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.css.twig"));

        $__internal_3e03fe23d5978796df45125649a93c0fb975045e4b39da3a631bde6ac53ed975 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3e03fe23d5978796df45125649a93c0fb975045e4b39da3a631bde6ac53ed975->enter($__internal_3e03fe23d5978796df45125649a93c0fb975045e4b39da3a631bde6ac53ed975_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_include($this->env, $context, "@Twig/Exception/exception.txt.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
*/
";
        
        $__internal_6997fbbeb2b0e5505c0a59f6177e2dcadaebdaf402db27bee25489118406acd9->leave($__internal_6997fbbeb2b0e5505c0a59f6177e2dcadaebdaf402db27bee25489118406acd9_prof);

        
        $__internal_3e03fe23d5978796df45125649a93c0fb975045e4b39da3a631bde6ac53ed975->leave($__internal_3e03fe23d5978796df45125649a93c0fb975045e4b39da3a631bde6ac53ed975_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ include('@Twig/Exception/exception.txt.twig', { exception: exception }) }}
*/
", "TwigBundle:Exception:exception.css.twig", "/var/www/movies/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/exception.css.twig");
    }
}
