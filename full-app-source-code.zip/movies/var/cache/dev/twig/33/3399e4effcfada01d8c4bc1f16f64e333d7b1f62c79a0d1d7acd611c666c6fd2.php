<?php

/* TwigBundle:Exception:exception.js.twig */
class __TwigTemplate_ad5ccb3332e94680c072e56f09271ed6e8caca563c92f6c714b4ce790ccef80a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c01d39d78ef4862e9ac23c0e593d747d6e6026e47ff451725706f60ece962ae8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c01d39d78ef4862e9ac23c0e593d747d6e6026e47ff451725706f60ece962ae8->enter($__internal_c01d39d78ef4862e9ac23c0e593d747d6e6026e47ff451725706f60ece962ae8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.js.twig"));

        $__internal_81544d0ff0ed9f2043613b53c6fecfb88edff0685d1b307fd457ef3c6fb17ce3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_81544d0ff0ed9f2043613b53c6fecfb88edff0685d1b307fd457ef3c6fb17ce3->enter($__internal_81544d0ff0ed9f2043613b53c6fecfb88edff0685d1b307fd457ef3c6fb17ce3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_include($this->env, $context, "@Twig/Exception/exception.txt.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
*/
";
        
        $__internal_c01d39d78ef4862e9ac23c0e593d747d6e6026e47ff451725706f60ece962ae8->leave($__internal_c01d39d78ef4862e9ac23c0e593d747d6e6026e47ff451725706f60ece962ae8_prof);

        
        $__internal_81544d0ff0ed9f2043613b53c6fecfb88edff0685d1b307fd457ef3c6fb17ce3->leave($__internal_81544d0ff0ed9f2043613b53c6fecfb88edff0685d1b307fd457ef3c6fb17ce3_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ include('@Twig/Exception/exception.txt.twig', { exception: exception }) }}
*/
", "TwigBundle:Exception:exception.js.twig", "/var/www/movies/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/exception.js.twig");
    }
}
