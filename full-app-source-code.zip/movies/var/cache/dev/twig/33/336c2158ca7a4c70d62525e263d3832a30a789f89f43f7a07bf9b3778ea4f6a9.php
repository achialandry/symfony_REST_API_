<?php

/* @Framework/Form/form_widget.html.php */
class __TwigTemplate_3175a1028da7c0a13c40212813a9ba22115f236122fb80a9582d20d3cdee4e6e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ee5db364a3c60c09d19e3934ec22007546602dc90c3fe910b86215de7a5000b0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ee5db364a3c60c09d19e3934ec22007546602dc90c3fe910b86215de7a5000b0->enter($__internal_ee5db364a3c60c09d19e3934ec22007546602dc90c3fe910b86215de7a5000b0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        $__internal_f003215d7b5842db7c5dda203425f16a234a7b2de96da772f084f35e8c867a82 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f003215d7b5842db7c5dda203425f16a234a7b2de96da772f084f35e8c867a82->enter($__internal_f003215d7b5842db7c5dda203425f16a234a7b2de96da772f084f35e8c867a82_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        // line 1
        echo "<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
";
        
        $__internal_ee5db364a3c60c09d19e3934ec22007546602dc90c3fe910b86215de7a5000b0->leave($__internal_ee5db364a3c60c09d19e3934ec22007546602dc90c3fe910b86215de7a5000b0_prof);

        
        $__internal_f003215d7b5842db7c5dda203425f16a234a7b2de96da772f084f35e8c867a82->leave($__internal_f003215d7b5842db7c5dda203425f16a234a7b2de96da772f084f35e8c867a82_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
", "@Framework/Form/form_widget.html.php", "/var/www/movies/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_widget.html.php");
    }
}
