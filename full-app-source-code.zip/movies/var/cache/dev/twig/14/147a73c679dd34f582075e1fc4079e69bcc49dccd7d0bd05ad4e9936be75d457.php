<?php

/* TwigBundle:Exception:error.xml.twig */
class __TwigTemplate_9c1f1e896211d5bdb6831966ea143b03be1922e1ab33137da8c8f53119a0baa8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b7901b097d581c8311ba8b2efc27494a37015a92b0847ff6058905a7291d5d74 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b7901b097d581c8311ba8b2efc27494a37015a92b0847ff6058905a7291d5d74->enter($__internal_b7901b097d581c8311ba8b2efc27494a37015a92b0847ff6058905a7291d5d74_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.xml.twig"));

        $__internal_f830f16eb07c48b7147d0c08623ff7a90ec370d7c2b2948568aa2f1652e4c24c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f830f16eb07c48b7147d0c08623ff7a90ec370d7c2b2948568aa2f1652e4c24c->enter($__internal_f830f16eb07c48b7147d0c08623ff7a90ec370d7c2b2948568aa2f1652e4c24c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.xml.twig"));

        // line 1
        echo "<?xml version=\"1.0\" encoding=\"";
        echo twig_escape_filter($this->env, $this->env->getCharset(), "html", null, true);
        echo "\" ?>

<error code=\"";
        // line 3
        echo twig_escape_filter($this->env, ($context["status_code"] ?? $this->getContext($context, "status_code")), "html", null, true);
        echo "\" message=\"";
        echo twig_escape_filter($this->env, ($context["status_text"] ?? $this->getContext($context, "status_text")), "html", null, true);
        echo "\" />
";
        
        $__internal_b7901b097d581c8311ba8b2efc27494a37015a92b0847ff6058905a7291d5d74->leave($__internal_b7901b097d581c8311ba8b2efc27494a37015a92b0847ff6058905a7291d5d74_prof);

        
        $__internal_f830f16eb07c48b7147d0c08623ff7a90ec370d7c2b2948568aa2f1652e4c24c->leave($__internal_f830f16eb07c48b7147d0c08623ff7a90ec370d7c2b2948568aa2f1652e4c24c_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.xml.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  31 => 3,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?xml version=\"1.0\" encoding=\"{{ _charset }}\" ?>

<error code=\"{{ status_code }}\" message=\"{{ status_text }}\" />
", "TwigBundle:Exception:error.xml.twig", "/var/www/movies/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.xml.twig");
    }
}
