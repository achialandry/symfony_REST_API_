<?php

/* @Framework/Form/integer_widget.html.php */
class __TwigTemplate_dc71b742ed3863e5712fb7bfdce455122652f5788b02b9b092ee7ec77470c4b3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d7293bb8716f243cbababd8e88b6be1341c9000f1d59c651691257afc9bae0a4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d7293bb8716f243cbababd8e88b6be1341c9000f1d59c651691257afc9bae0a4->enter($__internal_d7293bb8716f243cbababd8e88b6be1341c9000f1d59c651691257afc9bae0a4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/integer_widget.html.php"));

        $__internal_012530fbd0b371a32c8e3a9e5a1e989a4300068c63b68f506e0890ea97d2d36b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_012530fbd0b371a32c8e3a9e5a1e989a4300068c63b68f506e0890ea97d2d36b->enter($__internal_012530fbd0b371a32c8e3a9e5a1e989a4300068c63b68f506e0890ea97d2d36b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/integer_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'number')) ?>
";
        
        $__internal_d7293bb8716f243cbababd8e88b6be1341c9000f1d59c651691257afc9bae0a4->leave($__internal_d7293bb8716f243cbababd8e88b6be1341c9000f1d59c651691257afc9bae0a4_prof);

        
        $__internal_012530fbd0b371a32c8e3a9e5a1e989a4300068c63b68f506e0890ea97d2d36b->leave($__internal_012530fbd0b371a32c8e3a9e5a1e989a4300068c63b68f506e0890ea97d2d36b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/integer_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'number')) ?>
", "@Framework/Form/integer_widget.html.php", "/var/www/movies/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/integer_widget.html.php");
    }
}
