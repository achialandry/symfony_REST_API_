<?php

/* @Framework/Form/form_end.html.php */
class __TwigTemplate_95d08e7a92be59cfe132b82ca3d8d3b6de8c81794bc673762adde715631fe9ce extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_79d7bee8586f216ea303432972d365ee6e6d3d5907520ef9380c23751c0cb911 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_79d7bee8586f216ea303432972d365ee6e6d3d5907520ef9380c23751c0cb911->enter($__internal_79d7bee8586f216ea303432972d365ee6e6d3d5907520ef9380c23751c0cb911_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        $__internal_af6d3244d1f4f972adf58758d711a4e93709aebf65c15dcc1f2fef74f27db873 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_af6d3244d1f4f972adf58758d711a4e93709aebf65c15dcc1f2fef74f27db873->enter($__internal_af6d3244d1f4f972adf58758d711a4e93709aebf65c15dcc1f2fef74f27db873_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        // line 1
        echo "<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
";
        
        $__internal_79d7bee8586f216ea303432972d365ee6e6d3d5907520ef9380c23751c0cb911->leave($__internal_79d7bee8586f216ea303432972d365ee6e6d3d5907520ef9380c23751c0cb911_prof);

        
        $__internal_af6d3244d1f4f972adf58758d711a4e93709aebf65c15dcc1f2fef74f27db873->leave($__internal_af6d3244d1f4f972adf58758d711a4e93709aebf65c15dcc1f2fef74f27db873_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_end.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
", "@Framework/Form/form_end.html.php", "/var/www/movies/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_end.html.php");
    }
}
