<?php

/* @Framework/Form/choice_attributes.html.php */
class __TwigTemplate_d8ba664e98967e62c1a21ae5d8080fa2ec1d8cc8845aa3eb41f37b483aca00f3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1e57fe0af98df265d5e31739ddc8d1a45e9c2bc20c8559c29660464c8b897663 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1e57fe0af98df265d5e31739ddc8d1a45e9c2bc20c8559c29660464c8b897663->enter($__internal_1e57fe0af98df265d5e31739ddc8d1a45e9c2bc20c8559c29660464c8b897663_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_attributes.html.php"));

        $__internal_5c6d0da58e5673f9be8789b652044ddb1d734321c18e1218de33173e88b813a1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5c6d0da58e5673f9be8789b652044ddb1d734321c18e1218de33173e88b813a1->enter($__internal_5c6d0da58e5673f9be8789b652044ddb1d734321c18e1218de33173e88b813a1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_attributes.html.php"));

        // line 1
        echo "<?php if (\$disabled): ?>disabled=\"disabled\" <?php endif ?>
<?php foreach (\$choice_attr as \$k => \$v): ?>
<?php if (\$v === true): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$k)) ?>
<?php elseif (\$v !== false): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$v)) ?>
<?php endif ?>
<?php endforeach ?>
";
        
        $__internal_1e57fe0af98df265d5e31739ddc8d1a45e9c2bc20c8559c29660464c8b897663->leave($__internal_1e57fe0af98df265d5e31739ddc8d1a45e9c2bc20c8559c29660464c8b897663_prof);

        
        $__internal_5c6d0da58e5673f9be8789b652044ddb1d734321c18e1218de33173e88b813a1->leave($__internal_5c6d0da58e5673f9be8789b652044ddb1d734321c18e1218de33173e88b813a1_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$disabled): ?>disabled=\"disabled\" <?php endif ?>
<?php foreach (\$choice_attr as \$k => \$v): ?>
<?php if (\$v === true): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$k)) ?>
<?php elseif (\$v !== false): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$v)) ?>
<?php endif ?>
<?php endforeach ?>
", "@Framework/Form/choice_attributes.html.php", "/var/www/movies/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/choice_attributes.html.php");
    }
}
