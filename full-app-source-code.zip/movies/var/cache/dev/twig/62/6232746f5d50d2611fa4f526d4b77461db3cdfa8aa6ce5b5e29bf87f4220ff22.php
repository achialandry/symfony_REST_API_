<?php

/* @Framework/Form/radio_widget.html.php */
class __TwigTemplate_337d43315cbda1b2d646d2e70e18d4f8937b5c533fdc33cea09d390f30e26eeb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e95f05e20a9d8180460cb549e372c4b95b56010fe2ee7744e50824effc409b10 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e95f05e20a9d8180460cb549e372c4b95b56010fe2ee7744e50824effc409b10->enter($__internal_e95f05e20a9d8180460cb549e372c4b95b56010fe2ee7744e50824effc409b10_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        $__internal_c29b2b821bccfd0637e91887b24eb5e39294d6d8c5e5815a65b5c1952bb5bd06 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c29b2b821bccfd0637e91887b24eb5e39294d6d8c5e5815a65b5c1952bb5bd06->enter($__internal_c29b2b821bccfd0637e91887b24eb5e39294d6d8c5e5815a65b5c1952bb5bd06_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        // line 1
        echo "<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_e95f05e20a9d8180460cb549e372c4b95b56010fe2ee7744e50824effc409b10->leave($__internal_e95f05e20a9d8180460cb549e372c4b95b56010fe2ee7744e50824effc409b10_prof);

        
        $__internal_c29b2b821bccfd0637e91887b24eb5e39294d6d8c5e5815a65b5c1952bb5bd06->leave($__internal_c29b2b821bccfd0637e91887b24eb5e39294d6d8c5e5815a65b5c1952bb5bd06_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/radio_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
", "@Framework/Form/radio_widget.html.php", "/var/www/movies/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/radio_widget.html.php");
    }
}
