<?php

/* TwigBundle:Exception:error.json.twig */
class __TwigTemplate_54a2c9753be42b44135c4da854531f6d814fd507fa9455268ee41f1486a79d90 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_93477f0dc09873ec78d0ab16f3258101eec095cf00c7b3e570b240044e0b8913 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_93477f0dc09873ec78d0ab16f3258101eec095cf00c7b3e570b240044e0b8913->enter($__internal_93477f0dc09873ec78d0ab16f3258101eec095cf00c7b3e570b240044e0b8913_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.json.twig"));

        $__internal_a949774bb2c6439994ad986bf62b44337995ae9862ac026acd8b392516832a64 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a949774bb2c6439994ad986bf62b44337995ae9862ac026acd8b392516832a64->enter($__internal_a949774bb2c6439994ad986bf62b44337995ae9862ac026acd8b392516832a64_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => ($context["status_code"] ?? $this->getContext($context, "status_code")), "message" => ($context["status_text"] ?? $this->getContext($context, "status_text")))));
        echo "
";
        
        $__internal_93477f0dc09873ec78d0ab16f3258101eec095cf00c7b3e570b240044e0b8913->leave($__internal_93477f0dc09873ec78d0ab16f3258101eec095cf00c7b3e570b240044e0b8913_prof);

        
        $__internal_a949774bb2c6439994ad986bf62b44337995ae9862ac026acd8b392516832a64->leave($__internal_a949774bb2c6439994ad986bf62b44337995ae9862ac026acd8b392516832a64_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ { 'error': { 'code': status_code, 'message': status_text } }|json_encode|raw }}
", "TwigBundle:Exception:error.json.twig", "/var/www/movies/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.json.twig");
    }
}
