<?php

/* WebProfilerBundle:Collector:router.html.twig */
class __TwigTemplate_994962dddf6770796682e3c8ac0e461d0cf2cc71603e3a94fff72ef720d5ec13 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "WebProfilerBundle:Collector:router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_761d7c7da273502c4d7eb72cccb128b148605e6c7c04d21371f3098c43be8559 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_761d7c7da273502c4d7eb72cccb128b148605e6c7c04d21371f3098c43be8559->enter($__internal_761d7c7da273502c4d7eb72cccb128b148605e6c7c04d21371f3098c43be8559_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:router.html.twig"));

        $__internal_a83919bee8949a609b2e07963facb6028a6e279ab62a7cef0cd8fc0445597315 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a83919bee8949a609b2e07963facb6028a6e279ab62a7cef0cd8fc0445597315->enter($__internal_a83919bee8949a609b2e07963facb6028a6e279ab62a7cef0cd8fc0445597315_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_761d7c7da273502c4d7eb72cccb128b148605e6c7c04d21371f3098c43be8559->leave($__internal_761d7c7da273502c4d7eb72cccb128b148605e6c7c04d21371f3098c43be8559_prof);

        
        $__internal_a83919bee8949a609b2e07963facb6028a6e279ab62a7cef0cd8fc0445597315->leave($__internal_a83919bee8949a609b2e07963facb6028a6e279ab62a7cef0cd8fc0445597315_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_8d62fcb582a6113162ced1d764ccafe2830a9ec6161e1024b02736ec3f2ac634 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8d62fcb582a6113162ced1d764ccafe2830a9ec6161e1024b02736ec3f2ac634->enter($__internal_8d62fcb582a6113162ced1d764ccafe2830a9ec6161e1024b02736ec3f2ac634_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_6ddb90c54476112749a74e1a9261d3a96c0fe7ac8116b3fa07d86b8c92135003 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6ddb90c54476112749a74e1a9261d3a96c0fe7ac8116b3fa07d86b8c92135003->enter($__internal_6ddb90c54476112749a74e1a9261d3a96c0fe7ac8116b3fa07d86b8c92135003_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_6ddb90c54476112749a74e1a9261d3a96c0fe7ac8116b3fa07d86b8c92135003->leave($__internal_6ddb90c54476112749a74e1a9261d3a96c0fe7ac8116b3fa07d86b8c92135003_prof);

        
        $__internal_8d62fcb582a6113162ced1d764ccafe2830a9ec6161e1024b02736ec3f2ac634->leave($__internal_8d62fcb582a6113162ced1d764ccafe2830a9ec6161e1024b02736ec3f2ac634_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_2297642a67a5062299f6ed660f1cbd293db30dd9373bbd4be733e7fa9dc3b19f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2297642a67a5062299f6ed660f1cbd293db30dd9373bbd4be733e7fa9dc3b19f->enter($__internal_2297642a67a5062299f6ed660f1cbd293db30dd9373bbd4be733e7fa9dc3b19f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_d26c998c9b05adce603ee898e6106415efb300bbf5266a14061afd3ffabe5072 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d26c998c9b05adce603ee898e6106415efb300bbf5266a14061afd3ffabe5072->enter($__internal_d26c998c9b05adce603ee898e6106415efb300bbf5266a14061afd3ffabe5072_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_d26c998c9b05adce603ee898e6106415efb300bbf5266a14061afd3ffabe5072->leave($__internal_d26c998c9b05adce603ee898e6106415efb300bbf5266a14061afd3ffabe5072_prof);

        
        $__internal_2297642a67a5062299f6ed660f1cbd293db30dd9373bbd4be733e7fa9dc3b19f->leave($__internal_2297642a67a5062299f6ed660f1cbd293db30dd9373bbd4be733e7fa9dc3b19f_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_bf899ab7a8a7794ad1e38de2ed846ae00f33f61e6b1305884c3489260c80fbd0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bf899ab7a8a7794ad1e38de2ed846ae00f33f61e6b1305884c3489260c80fbd0->enter($__internal_bf899ab7a8a7794ad1e38de2ed846ae00f33f61e6b1305884c3489260c80fbd0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_01bfc988c782733f7270d311428c3f29ade17e949a52e4d513e58e292d570050 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_01bfc988c782733f7270d311428c3f29ade17e949a52e4d513e58e292d570050->enter($__internal_01bfc988c782733f7270d311428c3f29ade17e949a52e4d513e58e292d570050_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_01bfc988c782733f7270d311428c3f29ade17e949a52e4d513e58e292d570050->leave($__internal_01bfc988c782733f7270d311428c3f29ade17e949a52e4d513e58e292d570050_prof);

        
        $__internal_bf899ab7a8a7794ad1e38de2ed846ae00f33f61e6b1305884c3489260c80fbd0->leave($__internal_bf899ab7a8a7794ad1e38de2ed846ae00f33f61e6b1305884c3489260c80fbd0_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Collector:router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "WebProfilerBundle:Collector:router.html.twig", "/var/www/movies/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}
