<?php

/* @Framework/Form/button_widget.html.php */
class __TwigTemplate_958f035bb2bcd5fecf43441680ee30138f496344409aafc98666b28b70e3578d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0042966cbd5389c45399d50066e152ce499d677673dd3a57df538b01a5ce69d1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0042966cbd5389c45399d50066e152ce499d677673dd3a57df538b01a5ce69d1->enter($__internal_0042966cbd5389c45399d50066e152ce499d677673dd3a57df538b01a5ce69d1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_widget.html.php"));

        $__internal_28347e9731d48e41f8740840a76eea37ea47139dc5a6da47313efb185a5cd20a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_28347e9731d48e41f8740840a76eea37ea47139dc5a6da47313efb185a5cd20a->enter($__internal_28347e9731d48e41f8740840a76eea37ea47139dc5a6da47313efb185a5cd20a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_widget.html.php"));

        // line 1
        echo "<?php if (!\$label) { \$label = isset(\$label_format)
    ? strtr(\$label_format, array('%name%' => \$name, '%id%' => \$id))
    : \$view['form']->humanize(\$name); } ?>
<button type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'button' ?>\" <?php echo \$view['form']->block(\$form, 'button_attributes') ?>><?php echo \$view->escape(false !== \$translation_domain ? \$view['translator']->trans(\$label, array(), \$translation_domain) : \$label) ?></button>
";
        
        $__internal_0042966cbd5389c45399d50066e152ce499d677673dd3a57df538b01a5ce69d1->leave($__internal_0042966cbd5389c45399d50066e152ce499d677673dd3a57df538b01a5ce69d1_prof);

        
        $__internal_28347e9731d48e41f8740840a76eea37ea47139dc5a6da47313efb185a5cd20a->leave($__internal_28347e9731d48e41f8740840a76eea37ea47139dc5a6da47313efb185a5cd20a_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (!\$label) { \$label = isset(\$label_format)
    ? strtr(\$label_format, array('%name%' => \$name, '%id%' => \$id))
    : \$view['form']->humanize(\$name); } ?>
<button type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'button' ?>\" <?php echo \$view['form']->block(\$form, 'button_attributes') ?>><?php echo \$view->escape(false !== \$translation_domain ? \$view['translator']->trans(\$label, array(), \$translation_domain) : \$label) ?></button>
", "@Framework/Form/button_widget.html.php", "/var/www/movies/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/button_widget.html.php");
    }
}
