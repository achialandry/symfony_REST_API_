<?php

/* @Framework/Form/form.html.php */
class __TwigTemplate_bb5db68f3064ab9804408d7a5ae9cec35a7924f0f11717ec668da2d6d68b7303 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a3fb7fb8d04eacf015060106bd871eec681853f1739fd61b036fabdac13929fa = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a3fb7fb8d04eacf015060106bd871eec681853f1739fd61b036fabdac13929fa->enter($__internal_a3fb7fb8d04eacf015060106bd871eec681853f1739fd61b036fabdac13929fa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        $__internal_9f61d4fb4ceec8cf232b1416e063d014f91847de37fb622b30ddea34d0182eef = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9f61d4fb4ceec8cf232b1416e063d014f91847de37fb622b30ddea34d0182eef->enter($__internal_9f61d4fb4ceec8cf232b1416e063d014f91847de37fb622b30ddea34d0182eef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        // line 1
        echo "<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
";
        
        $__internal_a3fb7fb8d04eacf015060106bd871eec681853f1739fd61b036fabdac13929fa->leave($__internal_a3fb7fb8d04eacf015060106bd871eec681853f1739fd61b036fabdac13929fa_prof);

        
        $__internal_9f61d4fb4ceec8cf232b1416e063d014f91847de37fb622b30ddea34d0182eef->leave($__internal_9f61d4fb4ceec8cf232b1416e063d014f91847de37fb622b30ddea34d0182eef_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
", "@Framework/Form/form.html.php", "/var/www/movies/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form.html.php");
    }
}
