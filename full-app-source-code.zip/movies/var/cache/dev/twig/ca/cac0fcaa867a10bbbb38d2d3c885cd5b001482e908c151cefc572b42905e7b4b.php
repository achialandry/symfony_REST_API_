<?php

/* @Framework/Form/form_errors.html.php */
class __TwigTemplate_496849558183616aa67763a6e3bc98e7f7b69abc31ab27e6f422f14f1cdff969 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5031f7b7678267ad9d7de3d003a264436bf2e5eb3a2ae0e9c7f5e445de89800e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5031f7b7678267ad9d7de3d003a264436bf2e5eb3a2ae0e9c7f5e445de89800e->enter($__internal_5031f7b7678267ad9d7de3d003a264436bf2e5eb3a2ae0e9c7f5e445de89800e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        $__internal_f1b23b40a45fbdca62b9ace9ff02056be76918c3608290146a62553e6e512511 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f1b23b40a45fbdca62b9ace9ff02056be76918c3608290146a62553e6e512511->enter($__internal_f1b23b40a45fbdca62b9ace9ff02056be76918c3608290146a62553e6e512511_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        // line 1
        echo "<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
";
        
        $__internal_5031f7b7678267ad9d7de3d003a264436bf2e5eb3a2ae0e9c7f5e445de89800e->leave($__internal_5031f7b7678267ad9d7de3d003a264436bf2e5eb3a2ae0e9c7f5e445de89800e_prof);

        
        $__internal_f1b23b40a45fbdca62b9ace9ff02056be76918c3608290146a62553e6e512511->leave($__internal_f1b23b40a45fbdca62b9ace9ff02056be76918c3608290146a62553e6e512511_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_errors.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
", "@Framework/Form/form_errors.html.php", "/var/www/movies/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_errors.html.php");
    }
}
