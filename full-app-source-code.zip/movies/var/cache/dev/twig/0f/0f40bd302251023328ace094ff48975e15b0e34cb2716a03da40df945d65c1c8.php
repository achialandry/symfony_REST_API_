<?php

/* @Framework/FormTable/form_widget_compound.html.php */
class __TwigTemplate_c1e111211c1f4d73625a242df5334e6f03e137f85368deee8f428c1e596a0a18 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5ce672df8deae32a55b332053aa90549561691c8f60576ea40f81500c35b4313 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5ce672df8deae32a55b332053aa90549561691c8f60576ea40f81500c35b4313->enter($__internal_5ce672df8deae32a55b332053aa90549561691c8f60576ea40f81500c35b4313_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_widget_compound.html.php"));

        $__internal_56d754f42d2377931843b4d1e136d80b0fe6e6aa29b6805653d7bd10bbfdb247 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_56d754f42d2377931843b4d1e136d80b0fe6e6aa29b6805653d7bd10bbfdb247->enter($__internal_56d754f42d2377931843b4d1e136d80b0fe6e6aa29b6805653d7bd10bbfdb247_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_widget_compound.html.php"));

        // line 1
        echo "<table <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <tr>
        <td colspan=\"2\">
            <?php echo \$view['form']->errors(\$form) ?>
        </td>
    </tr>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</table>
";
        
        $__internal_5ce672df8deae32a55b332053aa90549561691c8f60576ea40f81500c35b4313->leave($__internal_5ce672df8deae32a55b332053aa90549561691c8f60576ea40f81500c35b4313_prof);

        
        $__internal_56d754f42d2377931843b4d1e136d80b0fe6e6aa29b6805653d7bd10bbfdb247->leave($__internal_56d754f42d2377931843b4d1e136d80b0fe6e6aa29b6805653d7bd10bbfdb247_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<table <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <tr>
        <td colspan=\"2\">
            <?php echo \$view['form']->errors(\$form) ?>
        </td>
    </tr>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</table>
", "@Framework/FormTable/form_widget_compound.html.php", "/var/www/movies/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/FormTable/form_widget_compound.html.php");
    }
}
