<?php

/* @Framework/Form/textarea_widget.html.php */
class __TwigTemplate_2c5c7ab50c44c5d6c6187f85a254569164a8506326aebbc76ff3172b8cf5e111 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c567dbc2a3952738c5868c0c272c87bdc61d01cb114bc9075b4a8f8b811eb383 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c567dbc2a3952738c5868c0c272c87bdc61d01cb114bc9075b4a8f8b811eb383->enter($__internal_c567dbc2a3952738c5868c0c272c87bdc61d01cb114bc9075b4a8f8b811eb383_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        $__internal_417b7e4b6b618020ea8ce193d11a1dc88c722b49e7cdc6b807ce3a5da501a54a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_417b7e4b6b618020ea8ce193d11a1dc88c722b49e7cdc6b807ce3a5da501a54a->enter($__internal_417b7e4b6b618020ea8ce193d11a1dc88c722b49e7cdc6b807ce3a5da501a54a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        // line 1
        echo "<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
";
        
        $__internal_c567dbc2a3952738c5868c0c272c87bdc61d01cb114bc9075b4a8f8b811eb383->leave($__internal_c567dbc2a3952738c5868c0c272c87bdc61d01cb114bc9075b4a8f8b811eb383_prof);

        
        $__internal_417b7e4b6b618020ea8ce193d11a1dc88c722b49e7cdc6b807ce3a5da501a54a->leave($__internal_417b7e4b6b618020ea8ce193d11a1dc88c722b49e7cdc6b807ce3a5da501a54a_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/textarea_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
", "@Framework/Form/textarea_widget.html.php", "/var/www/movies/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/textarea_widget.html.php");
    }
}
