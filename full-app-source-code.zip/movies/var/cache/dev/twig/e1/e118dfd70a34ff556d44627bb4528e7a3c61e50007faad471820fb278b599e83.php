<?php

/* @Framework/Form/reset_widget.html.php */
class __TwigTemplate_9fdf57936453dae9e7c2506ea9169997d7644e3c3c02c77dd17ad5a02fd57dd6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2d6544a55043b270ea6edbd8851c278267f0aab7d202c335ba851d26a8f8a951 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2d6544a55043b270ea6edbd8851c278267f0aab7d202c335ba851d26a8f8a951->enter($__internal_2d6544a55043b270ea6edbd8851c278267f0aab7d202c335ba851d26a8f8a951_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        $__internal_07e0311ca80b05fafc7d6fb4965f7b1ac52ab3ed2eda9d5f23162fb45f0ad950 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_07e0311ca80b05fafc7d6fb4965f7b1ac52ab3ed2eda9d5f23162fb45f0ad950->enter($__internal_07e0311ca80b05fafc7d6fb4965f7b1ac52ab3ed2eda9d5f23162fb45f0ad950_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'reset')) ?>
";
        
        $__internal_2d6544a55043b270ea6edbd8851c278267f0aab7d202c335ba851d26a8f8a951->leave($__internal_2d6544a55043b270ea6edbd8851c278267f0aab7d202c335ba851d26a8f8a951_prof);

        
        $__internal_07e0311ca80b05fafc7d6fb4965f7b1ac52ab3ed2eda9d5f23162fb45f0ad950->leave($__internal_07e0311ca80b05fafc7d6fb4965f7b1ac52ab3ed2eda9d5f23162fb45f0ad950_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/reset_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'reset')) ?>
", "@Framework/Form/reset_widget.html.php", "/var/www/movies/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/reset_widget.html.php");
    }
}
