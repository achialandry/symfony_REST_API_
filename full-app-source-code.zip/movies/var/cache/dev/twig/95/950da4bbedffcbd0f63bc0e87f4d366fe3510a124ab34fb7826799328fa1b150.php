<?php

/* @Framework/Form/button_row.html.php */
class __TwigTemplate_8586bbcaf2a13ea2f7f9c93cc9929b10ed6245f279c194175fec043ef9073802 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2fa3f232a1ea691b150519dea98badf582440e8069cbfb3ccca68e805f675e38 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2fa3f232a1ea691b150519dea98badf582440e8069cbfb3ccca68e805f675e38->enter($__internal_2fa3f232a1ea691b150519dea98badf582440e8069cbfb3ccca68e805f675e38_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        $__internal_e750099f80dd22f0b960dd9569078d39327c37697c09af6373ebea77ac901e37 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e750099f80dd22f0b960dd9569078d39327c37697c09af6373ebea77ac901e37->enter($__internal_e750099f80dd22f0b960dd9569078d39327c37697c09af6373ebea77ac901e37_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_2fa3f232a1ea691b150519dea98badf582440e8069cbfb3ccca68e805f675e38->leave($__internal_2fa3f232a1ea691b150519dea98badf582440e8069cbfb3ccca68e805f675e38_prof);

        
        $__internal_e750099f80dd22f0b960dd9569078d39327c37697c09af6373ebea77ac901e37->leave($__internal_e750099f80dd22f0b960dd9569078d39327c37697c09af6373ebea77ac901e37_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
", "@Framework/Form/button_row.html.php", "/var/www/movies/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/button_row.html.php");
    }
}
