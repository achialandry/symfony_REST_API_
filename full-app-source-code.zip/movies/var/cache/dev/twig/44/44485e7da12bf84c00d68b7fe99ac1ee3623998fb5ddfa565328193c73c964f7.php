<?php

/* TwigBundle:Exception:exception.atom.twig */
class __TwigTemplate_dffb0bdafedccf293e7118d5bc247add1022835d573ed5264b674c4dd30dd236 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ee416db9781c6e3a8506ca55615630687f8efa4a3deafcf474440a8ecb7bd3e9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ee416db9781c6e3a8506ca55615630687f8efa4a3deafcf474440a8ecb7bd3e9->enter($__internal_ee416db9781c6e3a8506ca55615630687f8efa4a3deafcf474440a8ecb7bd3e9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        $__internal_57eff05c3de4c826833cce0f2c302510758732c5a0af66fb5d773ec5b3b70e4b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_57eff05c3de4c826833cce0f2c302510758732c5a0af66fb5d773ec5b3b70e4b->enter($__internal_57eff05c3de4c826833cce0f2c302510758732c5a0af66fb5d773ec5b3b70e4b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/exception.xml.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
";
        
        $__internal_ee416db9781c6e3a8506ca55615630687f8efa4a3deafcf474440a8ecb7bd3e9->leave($__internal_ee416db9781c6e3a8506ca55615630687f8efa4a3deafcf474440a8ecb7bd3e9_prof);

        
        $__internal_57eff05c3de4c826833cce0f2c302510758732c5a0af66fb5d773ec5b3b70e4b->leave($__internal_57eff05c3de4c826833cce0f2c302510758732c5a0af66fb5d773ec5b3b70e4b_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/exception.xml.twig', { exception: exception }) }}
", "TwigBundle:Exception:exception.atom.twig", "/var/www/movies/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/exception.atom.twig");
    }
}
