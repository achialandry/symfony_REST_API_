<?php

/* @Framework/Form/choice_options.html.php */
class __TwigTemplate_4d95b93f48018fe01256edd08200498fbb42e9841b136ae3fef98c7ec156d988 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2ed5c6e8218f17177b82f30bc384662fc8a509e230f3955128e17746d4d65c79 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2ed5c6e8218f17177b82f30bc384662fc8a509e230f3955128e17746d4d65c79->enter($__internal_2ed5c6e8218f17177b82f30bc384662fc8a509e230f3955128e17746d4d65c79_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        $__internal_b6e8314b445afeb51ecbc74c5aca264a882e6ff07877ad7c71117ad35be4d548 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b6e8314b445afeb51ecbc74c5aca264a882e6ff07877ad7c71117ad35be4d548->enter($__internal_b6e8314b445afeb51ecbc74c5aca264a882e6ff07877ad7c71117ad35be4d548_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
        
        $__internal_2ed5c6e8218f17177b82f30bc384662fc8a509e230f3955128e17746d4d65c79->leave($__internal_2ed5c6e8218f17177b82f30bc384662fc8a509e230f3955128e17746d4d65c79_prof);

        
        $__internal_b6e8314b445afeb51ecbc74c5aca264a882e6ff07877ad7c71117ad35be4d548->leave($__internal_b6e8314b445afeb51ecbc74c5aca264a882e6ff07877ad7c71117ad35be4d548_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_options.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
", "@Framework/Form/choice_options.html.php", "/var/www/movies/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/choice_options.html.php");
    }
}
