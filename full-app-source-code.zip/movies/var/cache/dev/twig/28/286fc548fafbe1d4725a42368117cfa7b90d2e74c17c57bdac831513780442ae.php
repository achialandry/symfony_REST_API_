<?php

/* WebProfilerBundle:Profiler:open.html.twig */
class __TwigTemplate_69e884bb1c0016ff9a4b12d15bd20cb9d08cc7b86673ea92c9514ec266686663 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/base.html.twig", "WebProfilerBundle:Profiler:open.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2e1fb7ca9b60859fecab064411d3b3c689c21e4ac4408b73abc03cf1e485d40d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2e1fb7ca9b60859fecab064411d3b3c689c21e4ac4408b73abc03cf1e485d40d->enter($__internal_2e1fb7ca9b60859fecab064411d3b3c689c21e4ac4408b73abc03cf1e485d40d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:open.html.twig"));

        $__internal_f254cda0bc73051dc14760104a50715780aae38e72fd05760eb0372a0aa45c92 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f254cda0bc73051dc14760104a50715780aae38e72fd05760eb0372a0aa45c92->enter($__internal_f254cda0bc73051dc14760104a50715780aae38e72fd05760eb0372a0aa45c92_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:open.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2e1fb7ca9b60859fecab064411d3b3c689c21e4ac4408b73abc03cf1e485d40d->leave($__internal_2e1fb7ca9b60859fecab064411d3b3c689c21e4ac4408b73abc03cf1e485d40d_prof);

        
        $__internal_f254cda0bc73051dc14760104a50715780aae38e72fd05760eb0372a0aa45c92->leave($__internal_f254cda0bc73051dc14760104a50715780aae38e72fd05760eb0372a0aa45c92_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_4e2f09926964176f81edb5fd3566870c5eb51de9219afa5f408b770e544326bd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4e2f09926964176f81edb5fd3566870c5eb51de9219afa5f408b770e544326bd->enter($__internal_4e2f09926964176f81edb5fd3566870c5eb51de9219afa5f408b770e544326bd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_209a63015025f572d7f5c65709f0d6ca7f18b78572ff10deccd2486464ae0390 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_209a63015025f572d7f5c65709f0d6ca7f18b78572ff10deccd2486464ae0390->enter($__internal_209a63015025f572d7f5c65709f0d6ca7f18b78572ff10deccd2486464ae0390_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <style>
        ";
        // line 5
        echo twig_include($this->env, $context, "@WebProfiler/Profiler/open.css.twig");
        echo "
    </style>
";
        
        $__internal_209a63015025f572d7f5c65709f0d6ca7f18b78572ff10deccd2486464ae0390->leave($__internal_209a63015025f572d7f5c65709f0d6ca7f18b78572ff10deccd2486464ae0390_prof);

        
        $__internal_4e2f09926964176f81edb5fd3566870c5eb51de9219afa5f408b770e544326bd->leave($__internal_4e2f09926964176f81edb5fd3566870c5eb51de9219afa5f408b770e544326bd_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_6a1b3ee590759742ed082684ac08d92c768b07a703f999811289ac00528f9767 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6a1b3ee590759742ed082684ac08d92c768b07a703f999811289ac00528f9767->enter($__internal_6a1b3ee590759742ed082684ac08d92c768b07a703f999811289ac00528f9767_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_9e923ed9a17d63a7721b7502ecd1036ca363c83964cd49e8ca985203ac6e12fe = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9e923ed9a17d63a7721b7502ecd1036ca363c83964cd49e8ca985203ac6e12fe->enter($__internal_9e923ed9a17d63a7721b7502ecd1036ca363c83964cd49e8ca985203ac6e12fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "<div class=\"header\">
    <h1>";
        // line 11
        echo twig_escape_filter($this->env, ($context["file"] ?? $this->getContext($context, "file")), "html", null, true);
        echo " <small>line ";
        echo twig_escape_filter($this->env, ($context["line"] ?? $this->getContext($context, "line")), "html", null, true);
        echo "</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/";
        // line 12
        echo twig_escape_filter($this->env, twig_constant("Symfony\\Component\\HttpKernel\\Kernel::VERSION"), "html", null, true);
        echo "/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    ";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\CodeExtension')->fileExcerpt(($context["filename"] ?? $this->getContext($context, "filename")), ($context["line"] ?? $this->getContext($context, "line")),  -1);
        echo "
</div>
";
        
        $__internal_9e923ed9a17d63a7721b7502ecd1036ca363c83964cd49e8ca985203ac6e12fe->leave($__internal_9e923ed9a17d63a7721b7502ecd1036ca363c83964cd49e8ca985203ac6e12fe_prof);

        
        $__internal_6a1b3ee590759742ed082684ac08d92c768b07a703f999811289ac00528f9767->leave($__internal_6a1b3ee590759742ed082684ac08d92c768b07a703f999811289ac00528f9767_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:open.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 15,  84 => 12,  78 => 11,  75 => 10,  66 => 9,  53 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/base.html.twig' %}

{% block head %}
    <style>
        {{ include('@WebProfiler/Profiler/open.css.twig') }}
    </style>
{% endblock %}

{% block body %}
<div class=\"header\">
    <h1>{{ file }} <small>line {{ line }}</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/{{ constant('Symfony\\\\Component\\\\HttpKernel\\\\Kernel::VERSION') }}/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    {{ filename|file_excerpt(line, -1) }}
</div>
{% endblock %}
", "WebProfilerBundle:Profiler:open.html.twig", "/var/www/movies/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/open.html.twig");
    }
}
