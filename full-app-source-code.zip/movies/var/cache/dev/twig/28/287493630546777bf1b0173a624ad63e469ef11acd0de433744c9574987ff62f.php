<?php

/* @Framework/Form/password_widget.html.php */
class __TwigTemplate_2125669a685f1d3dd30b28ba8562f96927bb40951f43744d20449824bf2d9555 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0144fe8a6b81c2fc148ba109b0c5337e7b6136a2fec202ac8985f479684ed6fe = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0144fe8a6b81c2fc148ba109b0c5337e7b6136a2fec202ac8985f479684ed6fe->enter($__internal_0144fe8a6b81c2fc148ba109b0c5337e7b6136a2fec202ac8985f479684ed6fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        $__internal_ad20d364f123995b662c0553af1719a9ceb7ef11638a50b5ef13fc98135510fe = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ad20d364f123995b662c0553af1719a9ceb7ef11638a50b5ef13fc98135510fe->enter($__internal_ad20d364f123995b662c0553af1719a9ceb7ef11638a50b5ef13fc98135510fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'password')) ?>
";
        
        $__internal_0144fe8a6b81c2fc148ba109b0c5337e7b6136a2fec202ac8985f479684ed6fe->leave($__internal_0144fe8a6b81c2fc148ba109b0c5337e7b6136a2fec202ac8985f479684ed6fe_prof);

        
        $__internal_ad20d364f123995b662c0553af1719a9ceb7ef11638a50b5ef13fc98135510fe->leave($__internal_ad20d364f123995b662c0553af1719a9ceb7ef11638a50b5ef13fc98135510fe_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/password_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'password')) ?>
", "@Framework/Form/password_widget.html.php", "/var/www/movies/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/password_widget.html.php");
    }
}
