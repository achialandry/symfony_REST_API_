<?php

/* @Framework/Form/form_rest.html.php */
class __TwigTemplate_865991aee1503db9c73d526001a6548b55c4f185d3f5c998bbb7533c0f525e46 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0e5a118aa7b81ee1c093f02f63830b04562d5c5da6bb4cd8b89501c598c4c173 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0e5a118aa7b81ee1c093f02f63830b04562d5c5da6bb4cd8b89501c598c4c173->enter($__internal_0e5a118aa7b81ee1c093f02f63830b04562d5c5da6bb4cd8b89501c598c4c173_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rest.html.php"));

        $__internal_da6b2267fd9c7c8f893e71b44baeefae5a475854828a0e120b13000952978e3a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_da6b2267fd9c7c8f893e71b44baeefae5a475854828a0e120b13000952978e3a->enter($__internal_da6b2267fd9c7c8f893e71b44baeefae5a475854828a0e120b13000952978e3a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rest.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child): ?>
    <?php if (!\$child->isRendered()): ?>
        <?php echo \$view['form']->row(\$child) ?>
    <?php endif; ?>
<?php endforeach; ?>
";
        
        $__internal_0e5a118aa7b81ee1c093f02f63830b04562d5c5da6bb4cd8b89501c598c4c173->leave($__internal_0e5a118aa7b81ee1c093f02f63830b04562d5c5da6bb4cd8b89501c598c4c173_prof);

        
        $__internal_da6b2267fd9c7c8f893e71b44baeefae5a475854828a0e120b13000952978e3a->leave($__internal_da6b2267fd9c7c8f893e71b44baeefae5a475854828a0e120b13000952978e3a_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rest.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php foreach (\$form as \$child): ?>
    <?php if (!\$child->isRendered()): ?>
        <?php echo \$view['form']->row(\$child) ?>
    <?php endif; ?>
<?php endforeach; ?>
", "@Framework/Form/form_rest.html.php", "/var/www/movies/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_rest.html.php");
    }
}
