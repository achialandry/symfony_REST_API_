<?php

/* @Framework/Form/hidden_widget.html.php */
class __TwigTemplate_8e34281686aa9610fe141252198b9fe8d97ba38ab4ab008682393af9181533c0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9fb63594c8f84c6ed9d0dc630db9978973b86355d5b633ad463f2a97656ced75 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9fb63594c8f84c6ed9d0dc630db9978973b86355d5b633ad463f2a97656ced75->enter($__internal_9fb63594c8f84c6ed9d0dc630db9978973b86355d5b633ad463f2a97656ced75_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_widget.html.php"));

        $__internal_dee2cff04263921f914c7b31e23cc931a87fe9b3f0793cc6fc11e50194c437d1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dee2cff04263921f914c7b31e23cc931a87fe9b3f0793cc6fc11e50194c437d1->enter($__internal_dee2cff04263921f914c7b31e23cc931a87fe9b3f0793cc6fc11e50194c437d1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
";
        
        $__internal_9fb63594c8f84c6ed9d0dc630db9978973b86355d5b633ad463f2a97656ced75->leave($__internal_9fb63594c8f84c6ed9d0dc630db9978973b86355d5b633ad463f2a97656ced75_prof);

        
        $__internal_dee2cff04263921f914c7b31e23cc931a87fe9b3f0793cc6fc11e50194c437d1->leave($__internal_dee2cff04263921f914c7b31e23cc931a87fe9b3f0793cc6fc11e50194c437d1_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
", "@Framework/Form/hidden_widget.html.php", "/var/www/movies/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/hidden_widget.html.php");
    }
}
