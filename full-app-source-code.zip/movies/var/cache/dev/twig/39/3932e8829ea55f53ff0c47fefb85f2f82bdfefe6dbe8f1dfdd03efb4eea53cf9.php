<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_d9a0e4173902efc7ac58a991c0ecc938cd203792a8677a04fff6e55667e2e186 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ae07f9525925a211d2598672ffe3d0ef450e49391596450e90e222e2613c493e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ae07f9525925a211d2598672ffe3d0ef450e49391596450e90e222e2613c493e->enter($__internal_ae07f9525925a211d2598672ffe3d0ef450e49391596450e90e222e2613c493e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        $__internal_cf6039fd5fb06d88b4b9855198f0d2ab7e4e267b04d1bd025cffd428cee9975a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cf6039fd5fb06d88b4b9855198f0d2ab7e4e267b04d1bd025cffd428cee9975a->enter($__internal_cf6039fd5fb06d88b4b9855198f0d2ab7e4e267b04d1bd025cffd428cee9975a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_ae07f9525925a211d2598672ffe3d0ef450e49391596450e90e222e2613c493e->leave($__internal_ae07f9525925a211d2598672ffe3d0ef450e49391596450e90e222e2613c493e_prof);

        
        $__internal_cf6039fd5fb06d88b4b9855198f0d2ab7e4e267b04d1bd025cffd428cee9975a->leave($__internal_cf6039fd5fb06d88b4b9855198f0d2ab7e4e267b04d1bd025cffd428cee9975a_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@Framework/Form/button_label.html.php", "/var/www/movies/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/button_label.html.php");
    }
}
