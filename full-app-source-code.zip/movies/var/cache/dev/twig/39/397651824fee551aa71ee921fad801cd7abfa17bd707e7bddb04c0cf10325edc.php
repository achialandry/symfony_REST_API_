<?php

/* @WebProfiler/Icon/forward.svg */
class __TwigTemplate_d530bb95a0f94f5997794282b257dd0cc26f36ece5f875590c00794614eed28e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_61d9e97d1b92fd115bfa430fa6ae699cfb24abbec19b5134042d57cb789e3459 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_61d9e97d1b92fd115bfa430fa6ae699cfb24abbec19b5134042d57cb789e3459->enter($__internal_61d9e97d1b92fd115bfa430fa6ae699cfb24abbec19b5134042d57cb789e3459_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Icon/forward.svg"));

        $__internal_839e3c7f404ca2fa25fa73a71023e375d274b5a5f245c015ecae91ee3bbfb43b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_839e3c7f404ca2fa25fa73a71023e375d274b5a5f245c015ecae91ee3bbfb43b->enter($__internal_839e3c7f404ca2fa25fa73a71023e375d274b5a5f245c015ecae91ee3bbfb43b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Icon/forward.svg"));

        // line 1
        echo "<svg version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" x=\"0px\" y=\"0px\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" enable-background=\"new 0 0 24 24\" xml:space=\"preserve\">
    <path style=\"fill:#aaa\" d=\"M23.61,11.07L17.07,4.35A1.2,1.2,0,0,0,15,5.28V9H1.4A1.82,1.82,0,0,0,0,10.82v2.61A1.55,
        1.55,0,0,0,1.4,15H15v3.72a1.2,1.2,0,0,0,2.07.93l6.63-6.72A1.32,1.32,0,0,0,23.61,11.07Z\"/>
</svg>
";
        
        $__internal_61d9e97d1b92fd115bfa430fa6ae699cfb24abbec19b5134042d57cb789e3459->leave($__internal_61d9e97d1b92fd115bfa430fa6ae699cfb24abbec19b5134042d57cb789e3459_prof);

        
        $__internal_839e3c7f404ca2fa25fa73a71023e375d274b5a5f245c015ecae91ee3bbfb43b->leave($__internal_839e3c7f404ca2fa25fa73a71023e375d274b5a5f245c015ecae91ee3bbfb43b_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Icon/forward.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" x=\"0px\" y=\"0px\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" enable-background=\"new 0 0 24 24\" xml:space=\"preserve\">
    <path style=\"fill:#aaa\" d=\"M23.61,11.07L17.07,4.35A1.2,1.2,0,0,0,15,5.28V9H1.4A1.82,1.82,0,0,0,0,10.82v2.61A1.55,
        1.55,0,0,0,1.4,15H15v3.72a1.2,1.2,0,0,0,2.07.93l6.63-6.72A1.32,1.32,0,0,0,23.61,11.07Z\"/>
</svg>
", "@WebProfiler/Icon/forward.svg", "/var/www/movies/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Icon/forward.svg");
    }
}
