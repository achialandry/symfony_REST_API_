<?php

/* @Framework/Form/form_enctype.html.php */
class __TwigTemplate_8f7d48fb6aa3abf2ea5b89bb67324c7963374a941702eb291e3227e3cd8890ae extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7cb5c61a748ab89e232670f54fc73619b0e370193ee9f6dd6f90dd4907b3a9cd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7cb5c61a748ab89e232670f54fc73619b0e370193ee9f6dd6f90dd4907b3a9cd->enter($__internal_7cb5c61a748ab89e232670f54fc73619b0e370193ee9f6dd6f90dd4907b3a9cd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        $__internal_23022c6603f563967861dd316d26544a4bc86693686145d234f6a379a4a2fd13 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_23022c6603f563967861dd316d26544a4bc86693686145d234f6a379a4a2fd13->enter($__internal_23022c6603f563967861dd316d26544a4bc86693686145d234f6a379a4a2fd13_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        // line 1
        echo "<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
";
        
        $__internal_7cb5c61a748ab89e232670f54fc73619b0e370193ee9f6dd6f90dd4907b3a9cd->leave($__internal_7cb5c61a748ab89e232670f54fc73619b0e370193ee9f6dd6f90dd4907b3a9cd_prof);

        
        $__internal_23022c6603f563967861dd316d26544a4bc86693686145d234f6a379a4a2fd13->leave($__internal_23022c6603f563967861dd316d26544a4bc86693686145d234f6a379a4a2fd13_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_enctype.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
", "@Framework/Form/form_enctype.html.php", "/var/www/movies/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_enctype.html.php");
    }
}
