<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_0541a88dde80acf3cce098a96b4906b32d960b4be3b76a542c256949e852c97c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_03f41eca77dc29d7e114bf0ba0a51f5fb57d647ebc3128f00b26d21fa233cdf5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_03f41eca77dc29d7e114bf0ba0a51f5fb57d647ebc3128f00b26d21fa233cdf5->enter($__internal_03f41eca77dc29d7e114bf0ba0a51f5fb57d647ebc3128f00b26d21fa233cdf5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        $__internal_bd6636eb979d378555f2f15f9236efe1aff778fc50eb9717f554f9f3306534cc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bd6636eb979d378555f2f15f9236efe1aff778fc50eb9717f554f9f3306534cc->enter($__internal_bd6636eb979d378555f2f15f9236efe1aff778fc50eb9717f554f9f3306534cc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_03f41eca77dc29d7e114bf0ba0a51f5fb57d647ebc3128f00b26d21fa233cdf5->leave($__internal_03f41eca77dc29d7e114bf0ba0a51f5fb57d647ebc3128f00b26d21fa233cdf5_prof);

        
        $__internal_bd6636eb979d378555f2f15f9236efe1aff778fc50eb9717f554f9f3306534cc->leave($__internal_bd6636eb979d378555f2f15f9236efe1aff778fc50eb9717f554f9f3306534cc_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_397a11be2105307c588bcd734d15edad4afdb1d6605bb8d5d1c2193463993a2d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_397a11be2105307c588bcd734d15edad4afdb1d6605bb8d5d1c2193463993a2d->enter($__internal_397a11be2105307c588bcd734d15edad4afdb1d6605bb8d5d1c2193463993a2d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_ba5f846c6bfa9d09374dc9df47e055e89b0ac3f7a818712f7447660c2d56b238 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ba5f846c6bfa9d09374dc9df47e055e89b0ac3f7a818712f7447660c2d56b238->enter($__internal_ba5f846c6bfa9d09374dc9df47e055e89b0ac3f7a818712f7447660c2d56b238_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_ba5f846c6bfa9d09374dc9df47e055e89b0ac3f7a818712f7447660c2d56b238->leave($__internal_ba5f846c6bfa9d09374dc9df47e055e89b0ac3f7a818712f7447660c2d56b238_prof);

        
        $__internal_397a11be2105307c588bcd734d15edad4afdb1d6605bb8d5d1c2193463993a2d->leave($__internal_397a11be2105307c588bcd734d15edad4afdb1d6605bb8d5d1c2193463993a2d_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "WebProfilerBundle:Profiler:ajax_layout.html.twig", "/var/www/movies/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/ajax_layout.html.twig");
    }
}
