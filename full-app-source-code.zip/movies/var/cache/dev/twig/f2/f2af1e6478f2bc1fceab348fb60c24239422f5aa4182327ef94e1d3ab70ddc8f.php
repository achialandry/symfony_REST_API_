<?php

/* @Framework/Form/percent_widget.html.php */
class __TwigTemplate_2578ed193af9fed9fbcf1176610fdb57da0630b51c7dbe67c11d718427952ae9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_38b138a601b735eeeeb1502aa0415a9a49cae4ab3a164888938194680dcd4d5c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_38b138a601b735eeeeb1502aa0415a9a49cae4ab3a164888938194680dcd4d5c->enter($__internal_38b138a601b735eeeeb1502aa0415a9a49cae4ab3a164888938194680dcd4d5c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/percent_widget.html.php"));

        $__internal_28625415976c2b64509d3d2cb84ee6839b366ee94a4fac88a5865f393098e15d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_28625415976c2b64509d3d2cb84ee6839b366ee94a4fac88a5865f393098e15d->enter($__internal_28625415976c2b64509d3d2cb84ee6839b366ee94a4fac88a5865f393098e15d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/percent_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?> %
";
        
        $__internal_38b138a601b735eeeeb1502aa0415a9a49cae4ab3a164888938194680dcd4d5c->leave($__internal_38b138a601b735eeeeb1502aa0415a9a49cae4ab3a164888938194680dcd4d5c_prof);

        
        $__internal_28625415976c2b64509d3d2cb84ee6839b366ee94a4fac88a5865f393098e15d->leave($__internal_28625415976c2b64509d3d2cb84ee6839b366ee94a4fac88a5865f393098e15d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/percent_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?> %
", "@Framework/Form/percent_widget.html.php", "/var/www/movies/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/percent_widget.html.php");
    }
}
