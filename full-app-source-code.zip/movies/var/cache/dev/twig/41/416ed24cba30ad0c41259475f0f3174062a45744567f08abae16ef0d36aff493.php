<?php

/* @Framework/Form/widget_attributes.html.php */
class __TwigTemplate_bf725b35b2dd14c0f0af93aeddbda97549844f555a087d0db6363e83608a1b7f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b64d1fe8c49edbd0851bbd620956d5690cf90610167ada1f366c42b584fc6495 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b64d1fe8c49edbd0851bbd620956d5690cf90610167ada1f366c42b584fc6495->enter($__internal_b64d1fe8c49edbd0851bbd620956d5690cf90610167ada1f366c42b584fc6495_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/widget_attributes.html.php"));

        $__internal_4af78da02c1b00600ed1cb3efe63d8d80575bb41fdc214661aea9901686d1ccd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4af78da02c1b00600ed1cb3efe63d8d80575bb41fdc214661aea9901686d1ccd->enter($__internal_4af78da02c1b00600ed1cb3efe63d8d80575bb41fdc214661aea9901686d1ccd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/widget_attributes.html.php"));

        // line 1
        echo "id=\"<?php echo \$view->escape(\$id) ?>\" name=\"<?php echo \$view->escape(\$full_name) ?>\"<?php if (\$disabled): ?> disabled=\"disabled\"<?php endif ?>
<?php if (\$required): ?> required=\"required\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
";
        
        $__internal_b64d1fe8c49edbd0851bbd620956d5690cf90610167ada1f366c42b584fc6495->leave($__internal_b64d1fe8c49edbd0851bbd620956d5690cf90610167ada1f366c42b584fc6495_prof);

        
        $__internal_4af78da02c1b00600ed1cb3efe63d8d80575bb41fdc214661aea9901686d1ccd->leave($__internal_4af78da02c1b00600ed1cb3efe63d8d80575bb41fdc214661aea9901686d1ccd_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/widget_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("id=\"<?php echo \$view->escape(\$id) ?>\" name=\"<?php echo \$view->escape(\$full_name) ?>\"<?php if (\$disabled): ?> disabled=\"disabled\"<?php endif ?>
<?php if (\$required): ?> required=\"required\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
", "@Framework/Form/widget_attributes.html.php", "/var/www/movies/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/widget_attributes.html.php");
    }
}
