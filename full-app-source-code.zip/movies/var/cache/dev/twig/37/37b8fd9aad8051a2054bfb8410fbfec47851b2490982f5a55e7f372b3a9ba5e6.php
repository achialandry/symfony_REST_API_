<?php

/* WebProfilerBundle:Profiler:toolbar_redirect.html.twig */
class __TwigTemplate_a1f34043332ceabc7c82da17525eea7df96a075df6247912dbc71ef7b411a00a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_aeecdea2b190dc30ecbfab18b8b7e8b0bfce267040c9b65ee71bdd88cfcfc449 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_aeecdea2b190dc30ecbfab18b8b7e8b0bfce267040c9b65ee71bdd88cfcfc449->enter($__internal_aeecdea2b190dc30ecbfab18b8b7e8b0bfce267040c9b65ee71bdd88cfcfc449_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $__internal_f114bba56374d0282d6723230a699d8c305cc58b7129bb2d481f5e7ef7d8a801 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f114bba56374d0282d6723230a699d8c305cc58b7129bb2d481f5e7ef7d8a801->enter($__internal_f114bba56374d0282d6723230a699d8c305cc58b7129bb2d481f5e7ef7d8a801_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_aeecdea2b190dc30ecbfab18b8b7e8b0bfce267040c9b65ee71bdd88cfcfc449->leave($__internal_aeecdea2b190dc30ecbfab18b8b7e8b0bfce267040c9b65ee71bdd88cfcfc449_prof);

        
        $__internal_f114bba56374d0282d6723230a699d8c305cc58b7129bb2d481f5e7ef7d8a801->leave($__internal_f114bba56374d0282d6723230a699d8c305cc58b7129bb2d481f5e7ef7d8a801_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_d9dad33a39db0e330eb29f355e8f55ab10fcd00af229747e7f34cf898e62ed8c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d9dad33a39db0e330eb29f355e8f55ab10fcd00af229747e7f34cf898e62ed8c->enter($__internal_d9dad33a39db0e330eb29f355e8f55ab10fcd00af229747e7f34cf898e62ed8c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_46e06c0bf5733c9fa9d22095427c2147f548663026a9bd10347018df561f9c04 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_46e06c0bf5733c9fa9d22095427c2147f548663026a9bd10347018df561f9c04->enter($__internal_46e06c0bf5733c9fa9d22095427c2147f548663026a9bd10347018df561f9c04_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_46e06c0bf5733c9fa9d22095427c2147f548663026a9bd10347018df561f9c04->leave($__internal_46e06c0bf5733c9fa9d22095427c2147f548663026a9bd10347018df561f9c04_prof);

        
        $__internal_d9dad33a39db0e330eb29f355e8f55ab10fcd00af229747e7f34cf898e62ed8c->leave($__internal_d9dad33a39db0e330eb29f355e8f55ab10fcd00af229747e7f34cf898e62ed8c_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_d7faa1580cf1306a4474b844259ccab1dfe8967c281cf933d0cec17f0510b985 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d7faa1580cf1306a4474b844259ccab1dfe8967c281cf933d0cec17f0510b985->enter($__internal_d7faa1580cf1306a4474b844259ccab1dfe8967c281cf933d0cec17f0510b985_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_259198e9001842898ba6a0cef0328a66a3a01d5903ff819dbc3564e57c341262 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_259198e9001842898ba6a0cef0328a66a3a01d5903ff819dbc3564e57c341262->enter($__internal_259198e9001842898ba6a0cef0328a66a3a01d5903ff819dbc3564e57c341262_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, ($context["location"] ?? $this->getContext($context, "location")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, ($context["location"] ?? $this->getContext($context, "location")), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_259198e9001842898ba6a0cef0328a66a3a01d5903ff819dbc3564e57c341262->leave($__internal_259198e9001842898ba6a0cef0328a66a3a01d5903ff819dbc3564e57c341262_prof);

        
        $__internal_d7faa1580cf1306a4474b844259ccab1dfe8967c281cf933d0cec17f0510b985->leave($__internal_d7faa1580cf1306a4474b844259ccab1dfe8967c281cf933d0cec17f0510b985_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 8,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block title 'Redirection Intercepted' %}

{% block body %}
    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"{{ location }}\">{{ location }}</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
{% endblock %}
", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", "/var/www/movies/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/toolbar_redirect.html.twig");
    }
}
