<?php

/* @Framework/Form/hidden_row.html.php */
class __TwigTemplate_af95b32760fe1fe74eefa747fdf1e52f8b63eac31e87e8408cccf2d36c77394e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b2257ad414eda5f03478195143916f778bdfb42e709ce341159297833e9264e1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b2257ad414eda5f03478195143916f778bdfb42e709ce341159297833e9264e1->enter($__internal_b2257ad414eda5f03478195143916f778bdfb42e709ce341159297833e9264e1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        $__internal_ca4e3137a76969f88f6521fe1216a1c505a8bd19a9b4f5dedd90bb765f0e26ea = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ca4e3137a76969f88f6521fe1216a1c505a8bd19a9b4f5dedd90bb765f0e26ea->enter($__internal_ca4e3137a76969f88f6521fe1216a1c505a8bd19a9b4f5dedd90bb765f0e26ea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->widget(\$form) ?>
";
        
        $__internal_b2257ad414eda5f03478195143916f778bdfb42e709ce341159297833e9264e1->leave($__internal_b2257ad414eda5f03478195143916f778bdfb42e709ce341159297833e9264e1_prof);

        
        $__internal_ca4e3137a76969f88f6521fe1216a1c505a8bd19a9b4f5dedd90bb765f0e26ea->leave($__internal_ca4e3137a76969f88f6521fe1216a1c505a8bd19a9b4f5dedd90bb765f0e26ea_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->widget(\$form) ?>
", "@Framework/Form/hidden_row.html.php", "/var/www/movies/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/hidden_row.html.php");
    }
}
