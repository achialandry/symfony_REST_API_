<?php

/* @Framework/Form/repeated_row.html.php */
class __TwigTemplate_219a1191cf1a7edb66ac3fc3295e41c6ab9dd2753197d104ee3d87ac94f46720 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d6da49c86f80e97cc82600ea66cdf1bc5c1fe2b69fac4fd0c9d9d2fa3829ddf3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d6da49c86f80e97cc82600ea66cdf1bc5c1fe2b69fac4fd0c9d9d2fa3829ddf3->enter($__internal_d6da49c86f80e97cc82600ea66cdf1bc5c1fe2b69fac4fd0c9d9d2fa3829ddf3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        $__internal_9471cd50b353c764f66c56edad43e5a4a4c292fbd2045c9ec943f14e2294c02f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9471cd50b353c764f66c56edad43e5a4a4c292fbd2045c9ec943f14e2294c02f->enter($__internal_9471cd50b353c764f66c56edad43e5a4a4c292fbd2045c9ec943f14e2294c02f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_rows') ?>
";
        
        $__internal_d6da49c86f80e97cc82600ea66cdf1bc5c1fe2b69fac4fd0c9d9d2fa3829ddf3->leave($__internal_d6da49c86f80e97cc82600ea66cdf1bc5c1fe2b69fac4fd0c9d9d2fa3829ddf3_prof);

        
        $__internal_9471cd50b353c764f66c56edad43e5a4a4c292fbd2045c9ec943f14e2294c02f->leave($__internal_9471cd50b353c764f66c56edad43e5a4a4c292fbd2045c9ec943f14e2294c02f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/repeated_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_rows') ?>
", "@Framework/Form/repeated_row.html.php", "/var/www/movies/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/repeated_row.html.php");
    }
}
