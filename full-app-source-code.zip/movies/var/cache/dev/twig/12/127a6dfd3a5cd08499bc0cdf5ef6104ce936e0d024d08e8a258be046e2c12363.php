<?php

/* @Framework/Form/choice_widget.html.php */
class __TwigTemplate_c3ce4c23537a55221c0684ec813a0d23316e4e89fe05ca70cd99358422d09b58 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e4d60ba2b1e6c3922bb3c998240c917c8d7429f309b7c4955a0af28217c66e3c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e4d60ba2b1e6c3922bb3c998240c917c8d7429f309b7c4955a0af28217c66e3c->enter($__internal_e4d60ba2b1e6c3922bb3c998240c917c8d7429f309b7c4955a0af28217c66e3c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget.html.php"));

        $__internal_7e0a85e6cbd88657da89777337e20a88d0805b1d11d67705dfa4cc31e8264308 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7e0a85e6cbd88657da89777337e20a88d0805b1d11d67705dfa4cc31e8264308->enter($__internal_7e0a85e6cbd88657da89777337e20a88d0805b1d11d67705dfa4cc31e8264308_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget.html.php"));

        // line 1
        echo "<?php if (\$expanded): ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_expanded') ?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_collapsed') ?>
<?php endif ?>
";
        
        $__internal_e4d60ba2b1e6c3922bb3c998240c917c8d7429f309b7c4955a0af28217c66e3c->leave($__internal_e4d60ba2b1e6c3922bb3c998240c917c8d7429f309b7c4955a0af28217c66e3c_prof);

        
        $__internal_7e0a85e6cbd88657da89777337e20a88d0805b1d11d67705dfa4cc31e8264308->leave($__internal_7e0a85e6cbd88657da89777337e20a88d0805b1d11d67705dfa4cc31e8264308_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$expanded): ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_expanded') ?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_collapsed') ?>
<?php endif ?>
", "@Framework/Form/choice_widget.html.php", "/var/www/movies/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/choice_widget.html.php");
    }
}
