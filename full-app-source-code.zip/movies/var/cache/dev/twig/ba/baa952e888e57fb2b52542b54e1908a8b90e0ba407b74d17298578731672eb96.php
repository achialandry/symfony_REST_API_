<?php

/* TwigBundle:Exception:exception.rdf.twig */
class __TwigTemplate_869f60424c43ea913918e052d8c82bbf2dec0461accb7e0d0ff0019cc3221250 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9aaa4dd9caaf8e0a607696aea3aebb11b5bd36c258a75cd6506adf47eaf684ee = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9aaa4dd9caaf8e0a607696aea3aebb11b5bd36c258a75cd6506adf47eaf684ee->enter($__internal_9aaa4dd9caaf8e0a607696aea3aebb11b5bd36c258a75cd6506adf47eaf684ee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        $__internal_1b06daea897ae98714da464b413124d32f07a02cdbc4fa98d1b2983d3e89c06b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1b06daea897ae98714da464b413124d32f07a02cdbc4fa98d1b2983d3e89c06b->enter($__internal_1b06daea897ae98714da464b413124d32f07a02cdbc4fa98d1b2983d3e89c06b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/exception.xml.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
";
        
        $__internal_9aaa4dd9caaf8e0a607696aea3aebb11b5bd36c258a75cd6506adf47eaf684ee->leave($__internal_9aaa4dd9caaf8e0a607696aea3aebb11b5bd36c258a75cd6506adf47eaf684ee_prof);

        
        $__internal_1b06daea897ae98714da464b413124d32f07a02cdbc4fa98d1b2983d3e89c06b->leave($__internal_1b06daea897ae98714da464b413124d32f07a02cdbc4fa98d1b2983d3e89c06b_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/exception.xml.twig', { exception: exception }) }}
", "TwigBundle:Exception:exception.rdf.twig", "/var/www/movies/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/exception.rdf.twig");
    }
}
