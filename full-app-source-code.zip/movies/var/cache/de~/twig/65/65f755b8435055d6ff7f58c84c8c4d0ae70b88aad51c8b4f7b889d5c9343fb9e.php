<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_a35bb59a7ac0c63209f0f60d6fb9d5f3e54157d4d9b9bdf85a6f683c69bff53d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_162309fc1313d889f4afd0e1e3b030d9e2fe1a88f223e893da88eaf4118c4c46 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_162309fc1313d889f4afd0e1e3b030d9e2fe1a88f223e893da88eaf4118c4c46->enter($__internal_162309fc1313d889f4afd0e1e3b030d9e2fe1a88f223e893da88eaf4118c4c46_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_cd5fb1fba9c5b37df433b729b3f3ac15e866269cf2760c5212473c5416a479ed = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cd5fb1fba9c5b37df433b729b3f3ac15e866269cf2760c5212473c5416a479ed->enter($__internal_cd5fb1fba9c5b37df433b729b3f3ac15e866269cf2760c5212473c5416a479ed_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_162309fc1313d889f4afd0e1e3b030d9e2fe1a88f223e893da88eaf4118c4c46->leave($__internal_162309fc1313d889f4afd0e1e3b030d9e2fe1a88f223e893da88eaf4118c4c46_prof);

        
        $__internal_cd5fb1fba9c5b37df433b729b3f3ac15e866269cf2760c5212473c5416a479ed->leave($__internal_cd5fb1fba9c5b37df433b729b3f3ac15e866269cf2760c5212473c5416a479ed_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_4a29449e0025f1e85784eee887d428ed7e6d9e4d31a246133fe65deaf9d179cd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4a29449e0025f1e85784eee887d428ed7e6d9e4d31a246133fe65deaf9d179cd->enter($__internal_4a29449e0025f1e85784eee887d428ed7e6d9e4d31a246133fe65deaf9d179cd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_6db3e6446d3f6026d8f6e7ba0e936f118728b644ab28d8b01fdbe85af1fe4123 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6db3e6446d3f6026d8f6e7ba0e936f118728b644ab28d8b01fdbe85af1fe4123->enter($__internal_6db3e6446d3f6026d8f6e7ba0e936f118728b644ab28d8b01fdbe85af1fe4123_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_6db3e6446d3f6026d8f6e7ba0e936f118728b644ab28d8b01fdbe85af1fe4123->leave($__internal_6db3e6446d3f6026d8f6e7ba0e936f118728b644ab28d8b01fdbe85af1fe4123_prof);

        
        $__internal_4a29449e0025f1e85784eee887d428ed7e6d9e4d31a246133fe65deaf9d179cd->leave($__internal_4a29449e0025f1e85784eee887d428ed7e6d9e4d31a246133fe65deaf9d179cd_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_3736d167a88d50e93bbbc4f13d0a12f15d6774ccd33f58d5b2291a20f27f3173 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3736d167a88d50e93bbbc4f13d0a12f15d6774ccd33f58d5b2291a20f27f3173->enter($__internal_3736d167a88d50e93bbbc4f13d0a12f15d6774ccd33f58d5b2291a20f27f3173_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_de3f90fdadfd3b1fcb534d62c326a70767bee7f7ddb4acd04e5a1fad062e1897 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_de3f90fdadfd3b1fcb534d62c326a70767bee7f7ddb4acd04e5a1fad062e1897->enter($__internal_de3f90fdadfd3b1fcb534d62c326a70767bee7f7ddb4acd04e5a1fad062e1897_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_de3f90fdadfd3b1fcb534d62c326a70767bee7f7ddb4acd04e5a1fad062e1897->leave($__internal_de3f90fdadfd3b1fcb534d62c326a70767bee7f7ddb4acd04e5a1fad062e1897_prof);

        
        $__internal_3736d167a88d50e93bbbc4f13d0a12f15d6774ccd33f58d5b2291a20f27f3173->leave($__internal_3736d167a88d50e93bbbc4f13d0a12f15d6774ccd33f58d5b2291a20f27f3173_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_a78819627cb435f93dbeffa58dd7ce7e8a2ea3092ff999d6e3b8c869985ecd81 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a78819627cb435f93dbeffa58dd7ce7e8a2ea3092ff999d6e3b8c869985ecd81->enter($__internal_a78819627cb435f93dbeffa58dd7ce7e8a2ea3092ff999d6e3b8c869985ecd81_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_20ef10532657dab9e082cea4ca12478f45aa24ffe797e79eb73e0390f5dd2ce6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_20ef10532657dab9e082cea4ca12478f45aa24ffe797e79eb73e0390f5dd2ce6->enter($__internal_20ef10532657dab9e082cea4ca12478f45aa24ffe797e79eb73e0390f5dd2ce6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_20ef10532657dab9e082cea4ca12478f45aa24ffe797e79eb73e0390f5dd2ce6->leave($__internal_20ef10532657dab9e082cea4ca12478f45aa24ffe797e79eb73e0390f5dd2ce6_prof);

        
        $__internal_a78819627cb435f93dbeffa58dd7ce7e8a2ea3092ff999d6e3b8c869985ecd81->leave($__internal_a78819627cb435f93dbeffa58dd7ce7e8a2ea3092ff999d6e3b8c869985ecd81_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "/var/www/movies/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/exception.html.twig");
    }
}
